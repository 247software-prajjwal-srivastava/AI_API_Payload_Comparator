# API Payload Comparator

Automated tool that reads your React/Next.js v1 and v2 source code, auto-generates test scenarios for every CRUD operation it finds, runs them in the browser against both versions, intercepts the API payloads, and produces a visual diff report.

## How It Works

```
Phase 1: Code Analysis    → Babel AST parses both codebases for fetch/axios/form calls
Phase 2: Scenario Gen     → Matches v1↔v2 operations, builds executable test steps
Phase 3: Browser Exec     → Playwright drives both UIs, intercepts POST/PUT/PATCH/DELETE
Phase 4: Diff & Report    → Deep payload comparison → interactive HTML report
```

## Quick Start

```bash
# 1. Install
npm install

# 2. Edit config.json with your URLs, code paths, and login credentials

# 3. Run
node run.js
# or
npm start

# 4. Open
open reports/report.html
```

## CLI Options

```
--config <path>       Config file (default: ./config.json)
--v1-code <path>      v1 codebase path (overrides config)
--v2-code <path>      v2 codebase path (overrides config)
--v1-url <url>        v1 staging URL (overrides config)
--v2-url <url>        v2 staging URL (overrides config)
--analyze-only        Code analysis only — no browser
--scenarios-only      Analysis + scenario gen — no browser
--headed              Show the browser while running
--help                Print help
```

## Examples

```bash
# Full run with config defaults
node run.js

# Override paths via CLI
node run.js --v1-code ../old-app --v2-code ../new-app

# Local dev servers, visible browser
node run.js --headed --v1-url http://localhost:3000 --v2-url http://localhost:3001

# Just see what the analyzer finds (no browser needed)
node run.js --analyze-only

# Generate scenarios to review before running
node run.js --scenarios-only
# then: cat reports/scenarios.json
```

## Config

Edit `config.json`:

- **v1/v2 `codePath`** — path to each app's source code
- **v1/v2 `baseUrl`** — staging/prod URL for each version
- **v1/v2 `login`** — form-based login selectors and credentials
- **`options.ignoredPayloadFields`** — fields to skip in diffs (e.g. `_csrf`, `timestamp`)
- **`options.testData`** — values to fill into forms during testing

## Output

All outputs land in `reports/`:

| File | What |
|------|------|
| `report.html` | Interactive visual diff dashboard |
| `analysis.json` | Raw code analysis (all detected API calls, forms, interactions) |
| `scenarios.json` | Generated test scenarios with steps |
| `diff-report.json` | Machine-readable diff results |
| `execution-results.json` | Raw captured network requests |
| `screenshots/` | Page screenshots per scenario per version |

## What It Detects

- `fetch()` and `axios` calls (POST/PUT/PATCH/DELETE)
- Custom hooks (`useMutation`, `useCreate`, `useUpdate`, `useDelete`, etc.)
- HTML forms with field extraction
- Inline-edit patterns (onBlur, onDoubleClick, contentEditable)
- Next.js App Router and Pages Router file-based routing
- Field renames between versions (heuristic: same value + similar name)

## Requirements

- Node.js 18+
- Both codebases accessible on disk
- Both apps running/deployed at accessible URLs
