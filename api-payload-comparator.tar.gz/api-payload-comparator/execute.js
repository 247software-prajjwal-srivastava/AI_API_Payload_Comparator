/**
 * Phase 3: Playwright Execution Engine
 * 
 * Takes generated scenarios and runs them against both v1 and v2 UIs.
 * Intercepts all POST/PUT/PATCH/DELETE network requests and captures payloads.
 * 
 * For each scenario:
 * 1. Logs into the UI
 * 2. Navigates to the target page
 * 3. Performs interaction steps (fill forms, click buttons)
 * 4. Captures all mutation API requests and their payloads
 * 5. Takes screenshots on diffs (optional)
 */

const { chromium } = require("playwright");
const path = require("path");
const fs = require("fs");

const MUTATION_METHODS = ["POST", "PUT", "PATCH", "DELETE"];

class ExecutionEngine {
  constructor(config) {
    this.config = config;
    this.results = [];
  }

  async run(scenarios) {
    console.log("\n🚀 Starting execution engine...");
    console.log(`   Running ${scenarios.length} scenarios against both versions\n`);

    const browser = await chromium.launch({
      headless: this.config.options.headless !== false,
    });

    try {
      for (let i = 0; i < scenarios.length; i++) {
        const scenario = scenarios[i];
        console.log(`   [${i + 1}/${scenarios.length}] ${scenario.name}`);

        const result = {
          scenario,
          v1: null,
          v2: null,
          error: null,
        };

        // Execute on v1
        if (scenario.v1) {
          try {
            result.v1 = await this.executeOnVersion(browser, "v1", scenario.v1, scenario);
            console.log(`      ✓ v1: captured ${result.v1.capturedRequests.length} API calls`);
          } catch (err) {
            result.v1 = { error: err.message, capturedRequests: [] };
            console.log(`      ✗ v1: ${err.message}`);
          }
        }

        // Execute on v2
        if (scenario.v2) {
          try {
            result.v2 = await this.executeOnVersion(browser, "v2", scenario.v2, scenario);
            console.log(`      ✓ v2: captured ${result.v2.capturedRequests.length} API calls`);
          } catch (err) {
            result.v2 = { error: err.message, capturedRequests: [] };
            console.log(`      ✗ v2: ${err.message}`);
          }
        }

        this.results.push(result);
      }
    } finally {
      await browser.close();
    }

    return this.results;
  }

  async executeOnVersion(browser, version, versionConfig, scenario) {
    const baseConfig = this.config[version];
    const context = await browser.newContext({
      viewport: { width: 1280, height: 720 },
      ignoreHTTPSErrors: true,
    });
    const page = await context.newPage();

    const capturedRequests = [];
    const allNetworkActivity = [];

    // ─── Network interception ───
    page.on("request", (request) => {
      const method = request.method();
      const url = request.url();

      if (MUTATION_METHODS.includes(method)) {
        let body = null;
        try {
          const postData = request.postData();
          if (postData) {
            try {
              body = JSON.parse(postData);
            } catch {
              body = postData;
            }
          }
        } catch (e) {}

        const entry = {
          method,
          url,
          urlPath: new URL(url).pathname,
          body,
          headers: request.headers(),
          timestamp: Date.now(),
        };

        capturedRequests.push(entry);
        allNetworkActivity.push({ ...entry, type: "request" });
      }
    });

    page.on("response", (response) => {
      const request = response.request();
      const method = request.method();
      if (MUTATION_METHODS.includes(method)) {
        allNetworkActivity.push({
          type: "response",
          url: response.url(),
          status: response.status(),
          method,
          timestamp: Date.now(),
        });
      }
    });

    try {
      // ─── Step 1: Login ───
      await this.performLogin(page, baseConfig);

      // ─── Step 2: Execute scenario steps ───
      for (const step of versionConfig.steps) {
        await this.executeStep(page, step);
      }

      // ─── Step 3: Wait for any pending requests ───
      await page.waitForTimeout(this.config.options.waitAfterAction || 2000);

      // ─── Step 4: Screenshot (if enabled) ───
      let screenshot = null;
      if (this.config.options.screenshotOnDiff) {
        const ssDir = path.join(process.cwd(), "reports", "screenshots");
        if (!fs.existsSync(ssDir)) fs.mkdirSync(ssDir, { recursive: true });
        const ssPath = path.join(ssDir, `${scenario.id}_${version}.png`);
        await page.screenshot({ path: ssPath, fullPage: true });
        screenshot = ssPath;
      }

      return {
        capturedRequests,
        allNetworkActivity,
        screenshot,
        pageUrl: page.url(),
      };
    } finally {
      await context.close();
    }
  }

  async performLogin(page, versionConfig) {
    const login = versionConfig.login;
    if (!login || !login.url) return;

    const loginUrl = versionConfig.baseUrl + login.url;
    await page.goto(loginUrl, { waitUntil: "networkidle", timeout: this.config.options.timeout });

    // Fill username
    const usernameEl = await page.waitForSelector(login.usernameSelector, { timeout: 10000 });
    await usernameEl.fill(login.username);

    // Fill password
    const passwordEl = await page.waitForSelector(login.passwordSelector, { timeout: 5000 });
    await passwordEl.fill(login.password);

    // Submit
    const submitEl = await page.waitForSelector(login.submitSelector, { timeout: 5000 });
    await submitEl.click();

    // Wait for login to complete
    if (login.successIndicator) {
      try {
        await page.waitForURL(`**${login.successIndicator}**`, { timeout: 15000 });
      } catch {
        // If URL doesn't change, wait for navigation or network idle
        await page.waitForLoadState("networkidle", { timeout: 10000 }).catch(() => {});
      }
    } else {
      await page.waitForLoadState("networkidle", { timeout: 10000 }).catch(() => {});
    }
  }

  async executeStep(page, step) {
    const timeout = this.config.options.timeout || 30000;

    switch (step.action) {
      case "navigate": {
        const url = page.url().replace(/\/[^/]*$/, "") + step.target;
        // If the route is relative, combine with base URL already loaded
        const baseUrl = new URL(page.url()).origin;
        await page.goto(baseUrl + step.target, {
          waitUntil: "networkidle",
          timeout,
        });
        break;
      }

      case "wait": {
        await page.waitForTimeout(step.duration || 1000);
        break;
      }

      case "click": {
        const selectors = step.selectors || [step.selector];
        let clicked = false;

        for (const sel of selectors) {
          try {
            // Handle :contains pseudo-selector (not native CSS)
            if (sel.includes(":contains(")) {
              const match = sel.match(/:contains\(['"]?([^'")\]]+)['"]?\)/);
              if (match) {
                const tag = sel.split(":")[0] || "*";
                const text = match[1];
                const el = await page.$(`${tag}:has-text("${text}")`);
                if (el) {
                  await el.click();
                  clicked = true;
                  break;
                }
              }
            } else {
              const el = await page.$(sel);
              if (el) {
                await el.click();
                clicked = true;
                break;
              }
            }
          } catch (e) {
            continue;
          }
        }

        if (!clicked && !step.optional) {
          console.log(`         ⚠ Could not find clickable element for: ${step.description}`);
        }
        break;
      }

      case "click_first_record": {
        const selectors = step.selectors || [];
        let clicked = false;

        for (const sel of selectors) {
          try {
            const el = await page.$(sel);
            if (el) {
              await el.click();
              clicked = true;
              break;
            }
          } catch (e) {
            continue;
          }
        }

        if (!clicked) {
          // Fallback: click first link or row-like element
          const fallbacks = ["table tbody tr:first-child td:first-child a", "a[href]:not([href='#'])", "[role='row']:first-child"];
          for (const fb of fallbacks) {
            try {
              const el = await page.$(fb);
              if (el) {
                await el.click();
                break;
              }
            } catch (e) {
              continue;
            }
          }
        }
        break;
      }

      case "fill": {
        const selector = step.selector;
        try {
          const el = await page.waitForSelector(selector, { timeout: 5000 });
          if (!el) break;

          if (step.value === "__toggle__") {
            await el.click();
          } else if (step.value === "__select_first__") {
            await el.selectOption({ index: 1 });
          } else {
            await el.fill("");
            await el.fill(step.value);
          }
        } catch (e) {
          console.log(`         ⚠ Could not fill: ${step.description}`);
        }
        break;
      }

      case "fill_all_visible": {
        // Auto-detect and fill all visible input fields
        try {
          const inputs = await page.$$("input:visible, textarea:visible, select:visible");
          for (const input of inputs) {
            try {
              const type = await input.getAttribute("type") || "text";
              const tag = await input.evaluate((el) => el.tagName.toLowerCase());

              if (["hidden", "submit", "button", "file", "image"].includes(type)) continue;

              if (type === "checkbox" || type === "radio") {
                const checked = await input.isChecked();
                if (!checked) await input.click();
              } else if (tag === "select") {
                await input.selectOption({ index: 1 }).catch(() => {});
              } else if (tag === "textarea") {
                await input.fill(this.config.options.testData?.textarea || "Test data");
              } else {
                const name = (await input.getAttribute("name")) || "";
                const placeholder = (await input.getAttribute("placeholder")) || "";
                const hint = (name + " " + placeholder).toLowerCase();

                let value = this.config.options.testData?.string || "Test Data";
                if (hint.includes("email")) value = this.config.options.testData?.email || "test@example.com";
                else if (hint.includes("phone") || hint.includes("tel")) value = this.config.options.testData?.phone || "+1234567890";
                else if (hint.includes("url") || hint.includes("website")) value = this.config.options.testData?.url || "https://example.com";
                else if (type === "number") value = this.config.options.testData?.number || "123";
                else if (type === "date") value = this.config.options.testData?.date || "2026-01-15";
                else if (type === "password") value = "TestPass123!";

                await input.fill(value);
              }
            } catch (e) {
              // Skip individual field errors
            }
          }
        } catch (e) {
          console.log(`         ⚠ Auto-fill encountered an error`);
        }
        break;
      }

      default:
        console.log(`         ? Unknown step action: ${step.action}`);
    }
  }
}

module.exports = { ExecutionEngine };
