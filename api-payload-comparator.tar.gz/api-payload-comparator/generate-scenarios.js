/**
 * Phase 2: Scenario Generator
 * 
 * Takes the code analysis output from Phase 1 and generates executable
 * test scenarios that the Playwright runner can execute on both v1 and v2.
 * 
 * For each detected API mutation it creates:
 * - Navigation steps (go to the right page)
 * - Interaction steps (fill forms, click buttons, trigger edits)
 * - Expected API call to intercept
 */

class ScenarioGenerator {
  constructor(v1Analysis, v2Analysis, testData) {
    this.v1 = v1Analysis;
    this.v2 = v2Analysis;
    this.testData = testData || {};
  }

  generate() {
    console.log("\n📋 Generating test scenarios...");

    const scenarios = [];

    // 1. Match API calls between v1 and v2 by logical operation
    const matched = this.matchAPICalls();

    // 2. Generate scenarios for each matched pair
    for (const match of matched) {
      const scenario = this.buildScenario(match);
      if (scenario) scenarios.push(scenario);
    }

    // 3. Generate scenarios for unmatched (v1-only or v2-only) calls
    const unmatchedV1 = this.getUnmatched(this.v1.apiCalls, matched, "v1");
    const unmatchedV2 = this.getUnmatched(this.v2.apiCalls, matched, "v2");

    for (const call of unmatchedV1) {
      scenarios.push(this.buildSingleVersionScenario(call, "v1", "v1_only"));
    }
    for (const call of unmatchedV2) {
      scenarios.push(this.buildSingleVersionScenario(call, "v2", "v2_only"));
    }

    console.log(`   Generated ${scenarios.length} test scenarios`);
    console.log(`   ├─ ${matched.length} matched pairs (exist in both versions)`);
    console.log(`   ├─ ${unmatchedV1.length} v1-only APIs`);
    console.log(`   └─ ${unmatchedV2.length} v2-only APIs`);

    return scenarios;
  }

  /**
   * Match API calls between v1 and v2 by:
   * 1. Exact URL + method match
   * 2. Similar URL pattern + same method (e.g., /api/v1/users ↔ /api/v2/users)
   * 3. Same route/page + same method (likely the same operation)
   * 4. Similar endpoint name + same method
   */
  matchAPICalls() {
    const matches = [];
    const usedV1 = new Set();
    const usedV2 = new Set();

    const v1Calls = this.v1.apiCalls;
    const v2Calls = this.v2.apiCalls;

    // Pass 1: Exact URL match (ignoring version prefix)
    for (let i = 0; i < v1Calls.length; i++) {
      for (let j = 0; j < v2Calls.length; j++) {
        if (usedV1.has(i) || usedV2.has(j)) continue;
        if (v1Calls[i].method !== v2Calls[j].method) continue;

        const norm1 = this.normalizeUrl(v1Calls[i].url);
        const norm2 = this.normalizeUrl(v2Calls[j].url);

        if (norm1 === norm2 && norm1 !== "(dynamic)") {
          matches.push({ v1: v1Calls[i], v2: v2Calls[j], matchType: "exact_url" });
          usedV1.add(i);
          usedV2.add(j);
        }
      }
    }

    // Pass 2: Same route + same method
    for (let i = 0; i < v1Calls.length; i++) {
      for (let j = 0; j < v2Calls.length; j++) {
        if (usedV1.has(i) || usedV2.has(j)) continue;
        if (v1Calls[i].method !== v2Calls[j].method) continue;

        const route1 = this.normalizeRoute(v1Calls[i].route);
        const route2 = this.normalizeRoute(v2Calls[j].route);

        if (route1 === route2 && route1 !== "/") {
          matches.push({ v1: v1Calls[i], v2: v2Calls[j], matchType: "same_route" });
          usedV1.add(i);
          usedV2.add(j);
        }
      }
    }

    // Pass 3: Similar endpoint name (last segment of URL) + same method
    for (let i = 0; i < v1Calls.length; i++) {
      for (let j = 0; j < v2Calls.length; j++) {
        if (usedV1.has(i) || usedV2.has(j)) continue;
        if (v1Calls[i].method !== v2Calls[j].method) continue;

        const endpoint1 = this.extractEndpoint(v1Calls[i].url);
        const endpoint2 = this.extractEndpoint(v2Calls[j].url);

        if (endpoint1 && endpoint2 && endpoint1 === endpoint2) {
          matches.push({ v1: v1Calls[i], v2: v2Calls[j], matchType: "similar_endpoint" });
          usedV1.add(i);
          usedV2.add(j);
        }
      }
    }

    // Store used indices for unmatched detection
    this._usedV1 = usedV1;
    this._usedV2 = usedV2;

    return matches;
  }

  getUnmatched(calls, matches, version) {
    const usedSet = version === "v1" ? this._usedV1 : this._usedV2;
    return calls.filter((_, i) => !usedSet.has(i));
  }

  buildScenario(match) {
    const { v1, v2, matchType } = match;

    // Determine the logical operation name
    const opName = this.inferOperationName(v1, v2);

    // Find associated forms for both versions
    const v1Form = this.findAssociatedForm(v1, this.v1.forms);
    const v2Form = this.findAssociatedForm(v2, this.v2.forms);

    // Build interaction steps
    const v1Steps = this.buildSteps(v1, v1Form, "v1");
    const v2Steps = this.buildSteps(v2, v2Form, "v2");

    return {
      id: `${v1.method.toLowerCase()}_${opName.toLowerCase().replace(/\s+/g, "_")}`,
      name: `${v1.method} ${opName}`,
      method: v1.method,
      matchType,
      v1: {
        route: v1.route,
        apiUrl: v1.url,
        file: v1.file,
        steps: v1Steps,
        expectedPayloadFields: v1.payloadFields,
      },
      v2: {
        route: v2.route,
        apiUrl: v2.url,
        file: v2.file,
        steps: v2Steps,
        expectedPayloadFields: v2.payloadFields,
      },
    };
  }

  buildSingleVersionScenario(call, version, type) {
    const opName = this.inferOperationName(call, call);
    const forms = version === "v1" ? this.v1.forms : this.v2.forms;
    const form = this.findAssociatedForm(call, forms);
    const steps = this.buildSteps(call, form, version);

    return {
      id: `${type}_${call.method.toLowerCase()}_${opName.toLowerCase().replace(/\s+/g, "_")}`,
      name: `[${type.toUpperCase()}] ${call.method} ${opName}`,
      method: call.method,
      matchType: type,
      [version]: {
        route: call.route,
        apiUrl: call.url,
        file: call.file,
        steps,
        expectedPayloadFields: call.payloadFields,
      },
    };
  }

  buildSteps(apiCall, form, version) {
    const steps = [];

    // Step 1: Navigate to the route
    steps.push({
      action: "navigate",
      target: apiCall.route || "/",
      description: `Go to ${apiCall.route}`,
    });

    // Step 2: Wait for page to settle
    steps.push({
      action: "wait",
      duration: 1000,
      description: "Wait for page load",
    });

    // Step 3: If this is a PUT/PATCH/DELETE, we may need to click into a record first
    if (["PUT", "PATCH", "DELETE"].includes(apiCall.method)) {
      steps.push({
        action: "click_first_record",
        selectors: [
          "table tbody tr:first-child",
          "[data-testid*='row']:first-child",
          "[class*='list'] > *:first-child",
          "[class*='item']:first-child",
          "a[href*='/edit']",
          "a[href*='/detail']",
        ],
        description: "Click first available record",
      });
      steps.push({ action: "wait", duration: 1000, description: "Wait for record load" });
    }

    // Step 4: If DELETE, look for a delete button/trigger
    if (apiCall.method === "DELETE") {
      steps.push({
        action: "click",
        selectors: [
          "button[class*='delete'], button[class*='Delete']",
          "[data-testid*='delete']",
          "button:has(svg[class*='trash'])",
          "[aria-label*='delete' i], [aria-label*='remove' i]",
          "button[color='error'], button[color='danger']",
        ],
        description: "Click delete button",
      });
      steps.push({
        action: "click",
        selectors: [
          "button[class*='confirm'], button[class*='Confirm']",
          "[data-testid*='confirm']",
          ".modal button[type='submit']",
          ".dialog button:last-child",
          "button:contains('Yes'), button:contains('Confirm'), button:contains('Delete')",
        ],
        optional: true,
        description: "Confirm deletion if dialog appears",
      });
      return steps;
    }

    // Step 5: If there's a form, fill it
    if (form && form.fields.length > 0) {
      // If it's an edit operation, look for an edit button first
      if (["PUT", "PATCH"].includes(apiCall.method)) {
        steps.push({
          action: "click",
          selectors: [
            "button[class*='edit'], button[class*='Edit']",
            "[data-testid*='edit']",
            "[aria-label*='edit' i]",
            "button:has(svg[class*='pencil'], svg[class*='edit'])",
          ],
          optional: true,
          description: "Click edit button if needed",
        });
      }

      for (const field of form.fields) {
        const value = this.getTestValue(field);
        const selector = this.buildFieldSelector(field);

        steps.push({
          action: "fill",
          selector,
          value,
          fieldInfo: field,
          description: `Fill ${field.name || field.placeholder || field.id || "field"} = "${value}"`,
        });
      }

      // Submit the form
      steps.push({
        action: "click",
        selectors: [
          "button[type='submit']",
          "form button:last-of-type",
          "[data-testid*='submit'], [data-testid*='save']",
          "button:contains('Save'), button:contains('Submit'), button:contains('Create'), button:contains('Update')",
        ],
        description: "Submit the form",
      });
    } else {
      // No form found — try common patterns
      if (["POST"].includes(apiCall.method)) {
        steps.push({
          action: "click",
          selectors: [
            "button:contains('Add'), button:contains('Create'), button:contains('New')",
            "[data-testid*='create'], [data-testid*='add'], [data-testid*='new']",
            "a[href*='/new'], a[href*='/create']",
          ],
          description: "Click create/add button",
        });
        steps.push({ action: "wait", duration: 1000, description: "Wait for form/modal" });
        steps.push({
          action: "fill_all_visible",
          description: "Auto-fill all visible input fields",
        });
        steps.push({
          action: "click",
          selectors: [
            "button[type='submit']",
            "button:contains('Save'), button:contains('Submit'), button:contains('Create')",
          ],
          description: "Submit",
        });
      }
    }

    return steps;
  }

  findAssociatedForm(apiCall, forms) {
    // Try to find a form on the same route
    const sameRoute = forms.filter((f) => this.normalizeRoute(f.route) === this.normalizeRoute(apiCall.route));
    if (sameRoute.length === 1) return sameRoute[0];

    // Try same file
    const sameFile = forms.filter((f) => f.file === apiCall.file);
    if (sameFile.length === 1) return sameFile[0];

    // Return first from same route if multiple
    if (sameRoute.length > 0) return sameRoute[0];
    if (sameFile.length > 0) return sameFile[0];

    return null;
  }

  buildFieldSelector(field) {
    const selectors = [];
    if (field.name) selectors.push(`[name='${field.name}']`);
    if (field["data-testid"]) selectors.push(`[data-testid='${field["data-testid"]}']`);
    if (field.id) selectors.push(`#${field.id}`);
    if (field.placeholder) selectors.push(`[placeholder='${field.placeholder}']`);
    if (field["aria-label"]) selectors.push(`[aria-label='${field["aria-label"]}']`);
    return selectors.join(", ") || `input[type='${field.type || "text"}']`;
  }

  getTestValue(field) {
    const type = (field.type || "text").toLowerCase();
    const name = (field.name || field.placeholder || "").toLowerCase();

    if (name.includes("email")) return this.testData.email || "autotest@example.com";
    if (name.includes("phone") || name.includes("tel")) return this.testData.phone || "+1234567890";
    if (name.includes("url") || name.includes("website")) return this.testData.url || "https://example.com";
    if (name.includes("date")) return this.testData.date || "2026-01-15";
    if (name.includes("password")) return "TestPass123!";

    if (type === "email") return this.testData.email || "autotest@example.com";
    if (type === "number") return this.testData.number || "12345";
    if (type === "tel") return this.testData.phone || "+1234567890";
    if (type === "url") return this.testData.url || "https://example.com";
    if (type === "date") return this.testData.date || "2026-01-15";
    if (field.tag === "textarea") return this.testData.textarea || "Automated test input";
    if (type === "checkbox" || type === "radio") return "__toggle__";
    if (type === "select" || field.tag === "select") return "__select_first__";

    return this.testData.string || "Test Automation Data";
  }

  inferOperationName(v1Call, v2Call) {
    // Try to extract a meaningful name from the URL
    const url = v1Call.url || v2Call.url || "";
    const parts = url.replace(/\/api\/(v\d+\/)?/, "").split("/").filter(Boolean);

    // Remove dynamic segments
    const meaningful = parts.filter((p) => !p.startsWith("${") && !p.startsWith(":") && !/^\d+$/.test(p));

    if (meaningful.length > 0) {
      return meaningful.map((s) => s.charAt(0).toUpperCase() + s.slice(1)).join(" ");
    }

    // Fallback to route
    const route = v1Call.route || v2Call.route || "";
    const routeParts = route.split("/").filter(Boolean);
    if (routeParts.length > 0) return routeParts[routeParts.length - 1];

    return "Unknown Operation";
  }

  normalizeUrl(url) {
    if (!url) return "(dynamic)";
    return url
      .replace(/\/api\/(v\d+\/)?/, "/api/")
      .replace(/\/\d+/g, "/:id")
      .replace(/\/\$\{[^}]+\}/g, "/:id");
  }

  normalizeRoute(route) {
    if (!route) return "/";
    return route.replace(/:\w+/g, ":param").replace(/\/+$/, "") || "/";
  }

  extractEndpoint(url) {
    if (!url || url === "(dynamic)") return null;
    const parts = url.split("/").filter(Boolean);
    // Get last non-dynamic segment
    for (let i = parts.length - 1; i >= 0; i--) {
      if (!parts[i].startsWith("${") && !parts[i].startsWith(":") && !/^\d+$/.test(parts[i]) && !["api", "v1", "v2", "v3"].includes(parts[i])) {
        return parts[i].toLowerCase();
      }
    }
    return null;
  }
}

module.exports = { ScenarioGenerator };
