/**
 * Phase 4: Diff Engine
 * 
 * Takes execution results and performs deep comparison of captured payloads.
 * Pairs matching API calls from v1 and v2, then diffs their payloads.
 * 
 * Produces a structured diff report with:
 * - Added/removed/changed fields
 * - Type changes
 * - Structural changes (flat → nested, etc.)
 * - Field renames (heuristic detection)
 */

class DiffEngine {
  constructor(ignoredFields = []) {
    this.ignoredFields = new Set(ignoredFields);
  }

  compareResults(executionResults) {
    console.log("\n🔬 Comparing payloads...\n");

    const report = {
      timestamp: new Date().toISOString(),
      summary: { total: 0, matched: 0, diffs_found: 0, v1_only: 0, v2_only: 0, errors: 0 },
      comparisons: [],
    };

    for (const result of executionResults) {
      report.summary.total++;

      if (result.v1?.error || result.v2?.error) {
        report.summary.errors++;
        report.comparisons.push({
          scenario: result.scenario.name,
          status: "error",
          error: result.v1?.error || result.v2?.error,
        });
        continue;
      }

      // Only one version exists
      if (!result.v1 || !result.v2) {
        const version = result.v1 ? "v1_only" : "v2_only";
        report.summary[version]++;
        const data = result.v1 || result.v2;
        report.comparisons.push({
          scenario: result.scenario.name,
          status: version,
          capturedRequests: data.capturedRequests,
          screenshot: data.screenshot,
        });
        continue;
      }

      // Both versions — pair and compare captured requests
      const paired = this.pairRequests(result.v1.capturedRequests, result.v2.capturedRequests);

      const comparison = {
        scenario: result.scenario.name,
        method: result.scenario.method,
        status: "compared",
        pairs: [],
        v1OnlyRequests: paired.v1Only,
        v2OnlyRequests: paired.v2Only,
        v1Screenshot: result.v1.screenshot,
        v2Screenshot: result.v2.screenshot,
      };

      let hasDiffs = false;

      for (const pair of paired.matched) {
        const diff = this.deepDiff(pair.v1.body, pair.v2.body);
        const filteredDiff = diff.filter((d) => !this.isIgnoredPath(d.path));
        const renames = this.detectRenames(filteredDiff);

        if (filteredDiff.length > 0) hasDiffs = true;

        comparison.pairs.push({
          v1Url: pair.v1.urlPath,
          v2Url: pair.v2.urlPath,
          method: pair.v1.method,
          v1Payload: pair.v1.body,
          v2Payload: pair.v2.body,
          diffs: filteredDiff,
          renames,
          identical: filteredDiff.length === 0,
        });
      }

      if (hasDiffs || paired.v1Only.length || paired.v2Only.length) {
        comparison.status = "diffs_found";
        report.summary.diffs_found++;
      } else {
        comparison.status = "identical";
        report.summary.matched++;
      }

      report.comparisons.push(comparison);
    }

    console.log(`   Summary:`);
    console.log(`   ├─ Total scenarios:  ${report.summary.total}`);
    console.log(`   ├─ Identical:        ${report.summary.matched}`);
    console.log(`   ├─ Diffs found:      ${report.summary.diffs_found}`);
    console.log(`   ├─ v1-only:          ${report.summary.v1_only}`);
    console.log(`   ├─ v2-only:          ${report.summary.v2_only}`);
    console.log(`   └─ Errors:           ${report.summary.errors}`);

    return report;
  }

  /**
   * Pair captured requests from v1 and v2.
   * Matching by: same method + similar URL path
   */
  pairRequests(v1Reqs, v2Reqs) {
    const matched = [];
    const usedV2 = new Set();

    for (const v1Req of v1Reqs) {
      let bestMatch = null;
      let bestScore = 0;

      for (let j = 0; j < v2Reqs.length; j++) {
        if (usedV2.has(j)) continue;
        if (v1Req.method !== v2Reqs[j].method) continue;

        const score = this.urlSimilarity(v1Req.urlPath, v2Reqs[j].urlPath);
        if (score > bestScore) {
          bestScore = score;
          bestMatch = j;
        }
      }

      if (bestMatch !== null && bestScore > 0.3) {
        matched.push({ v1: v1Req, v2: v2Reqs[bestMatch] });
        usedV2.add(bestMatch);
      }
    }

    const v1Only = v1Reqs.filter((_, i) => !matched.some((m) => m.v1 === v1Reqs[i]));
    const v2Only = v2Reqs.filter((_, j) => !usedV2.has(j));

    return { matched, v1Only, v2Only };
  }

  urlSimilarity(url1, url2) {
    if (!url1 || !url2) return 0;

    // Normalize: remove version prefixes, replace IDs with placeholder
    const norm = (u) =>
      u
        .replace(/\/v\d+\//, "/")
        .replace(/\/\d+/g, "/:id")
        .replace(/\/[a-f0-9-]{36}/g, "/:uuid")
        .toLowerCase();

    const n1 = norm(url1);
    const n2 = norm(url2);

    if (n1 === n2) return 1.0;

    // Segment-based similarity
    const s1 = n1.split("/").filter(Boolean);
    const s2 = n2.split("/").filter(Boolean);
    const maxLen = Math.max(s1.length, s2.length);
    if (maxLen === 0) return 0;

    let matching = 0;
    for (let i = 0; i < Math.min(s1.length, s2.length); i++) {
      if (s1[i] === s2[i]) matching++;
      // Check if same resource name but different prefix
      else if (s1[s1.length - 1] === s2[s2.length - 1]) matching += 0.5;
    }

    return matching / maxLen;
  }

  /**
   * Deep diff two objects, returning an array of differences
   */
  deepDiff(a, b, pathPrefix = "") {
    const diffs = [];

    if (a === b) return diffs;
    if (a === null && b === null) return diffs;
    if (a === undefined && b === undefined) return diffs;

    if (a === undefined || a === null) {
      diffs.push({ path: pathPrefix || "(root)", type: "added", v1Value: a, v2Value: b });
      return diffs;
    }
    if (b === undefined || b === null) {
      diffs.push({ path: pathPrefix || "(root)", type: "removed", v1Value: a, v2Value: b });
      return diffs;
    }

    const typeA = Array.isArray(a) ? "array" : typeof a;
    const typeB = Array.isArray(b) ? "array" : typeof b;

    if (typeA !== typeB) {
      diffs.push({
        path: pathPrefix || "(root)",
        type: "type_changed",
        v1Value: a,
        v2Value: b,
        v1Type: typeA,
        v2Type: typeB,
      });
      return diffs;
    }

    if (typeA === "array") {
      const maxLen = Math.max(a.length, b.length);
      if (a.length !== b.length) {
        diffs.push({
          path: pathPrefix || "(root)",
          type: "array_length_changed",
          v1Value: a.length,
          v2Value: b.length,
        });
      }
      for (let i = 0; i < maxLen; i++) {
        diffs.push(...this.deepDiff(a[i], b[i], `${pathPrefix}[${i}]`));
      }
      return diffs;
    }

    if (typeA === "object") {
      const allKeys = new Set([...Object.keys(a), ...Object.keys(b)]);
      for (const key of allKeys) {
        const newPath = pathPrefix ? `${pathPrefix}.${key}` : key;
        if (!(key in a)) {
          diffs.push({ path: newPath, type: "added", v1Value: undefined, v2Value: b[key] });
        } else if (!(key in b)) {
          diffs.push({ path: newPath, type: "removed", v1Value: a[key], v2Value: undefined });
        } else {
          diffs.push(...this.deepDiff(a[key], b[key], newPath));
        }
      }
      return diffs;
    }

    // Primitives
    if (a !== b) {
      diffs.push({ path: pathPrefix || "(root)", type: "value_changed", v1Value: a, v2Value: b });
    }

    return diffs;
  }

  /**
   * Heuristic rename detection:
   * If a field was "removed" in v1 and "added" in v2 with similar names or same values,
   * it's likely a rename.
   */
  detectRenames(diffs) {
    const removed = diffs.filter((d) => d.type === "removed");
    const added = diffs.filter((d) => d.type === "added");
    const renames = [];

    for (const rem of removed) {
      for (const add of added) {
        const score = this.renameScore(rem, add);
        if (score > 0.5) {
          renames.push({
            v1Field: rem.path,
            v2Field: add.path,
            confidence: score,
            v1Value: rem.v1Value,
            v2Value: add.v2Value,
          });
        }
      }
    }

    return renames;
  }

  renameScore(removed, added) {
    let score = 0;

    // Same value → strong signal
    const v1Val = JSON.stringify(removed.v1Value);
    const v2Val = JSON.stringify(added.v2Value);
    if (v1Val === v2Val && v1Val !== undefined) score += 0.6;

    // Similar field names
    const name1 = removed.path.split(".").pop().toLowerCase();
    const name2 = added.path.split(".").pop().toLowerCase();

    if (name1.includes(name2) || name2.includes(name1)) score += 0.3;
    if (this.levenshteinRatio(name1, name2) > 0.6) score += 0.2;

    // Same parent path
    const parent1 = removed.path.split(".").slice(0, -1).join(".");
    const parent2 = added.path.split(".").slice(0, -1).join(".");
    if (parent1 === parent2) score += 0.1;

    return Math.min(score, 1.0);
  }

  levenshteinRatio(s1, s2) {
    if (!s1.length || !s2.length) return 0;
    const maxLen = Math.max(s1.length, s2.length);
    if (maxLen === 0) return 1;

    const matrix = [];
    for (let i = 0; i <= s1.length; i++) {
      matrix[i] = [i];
      for (let j = 1; j <= s2.length; j++) {
        if (i === 0) {
          matrix[i][j] = j;
        } else {
          const cost = s1[i - 1] === s2[j - 1] ? 0 : 1;
          matrix[i][j] = Math.min(
            matrix[i - 1][j] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j - 1] + cost
          );
        }
      }
    }

    return 1 - matrix[s1.length][s2.length] / maxLen;
  }

  isIgnoredPath(fieldPath) {
    const lastSegment = fieldPath.split(".").pop();
    return this.ignoredFields.has(lastSegment);
  }
}

module.exports = { DiffEngine };
