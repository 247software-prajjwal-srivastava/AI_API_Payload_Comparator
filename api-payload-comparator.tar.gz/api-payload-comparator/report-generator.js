/**
 * Report Generator
 * 
 * Takes the diff report and generates a self-contained, styled HTML report
 * with interactive sections, side-by-side payload comparison, and summary dashboard.
 */

const fs = require("fs");
const path = require("path");

class ReportGenerator {
  generate(report, outputPath) {
    const html = this.buildHTML(report);
    fs.writeFileSync(outputPath, html, "utf-8");
    console.log(`\n📄 Report saved to: ${outputPath}`);
    return outputPath;
  }

  buildHTML(report) {
    const { summary, comparisons, timestamp } = report;

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>API Payload Comparison Report</title>
  <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }

    :root {
      --bg: #0a0c10;
      --surface: #12151c;
      --surface2: #1a1e28;
      --border: #252a36;
      --text: #e2e8f0;
      --text-dim: #7a8599;
      --accent: #38bdf8;
      --green: #34d399;
      --red: #f87171;
      --amber: #fbbf24;
      --purple: #a78bfa;
      --font-mono: 'IBM Plex Mono', monospace;
      --font-sans: 'DM Sans', system-ui, sans-serif;
    }

    body {
      background: var(--bg);
      color: var(--text);
      font-family: var(--font-sans);
      line-height: 1.6;
      padding: 40px 24px;
    }

    .container { max-width: 1200px; margin: 0 auto; }

    header {
      margin-bottom: 48px;
      border-bottom: 1px solid var(--border);
      padding-bottom: 32px;
    }

    header h1 {
      font-size: 28px;
      font-weight: 700;
      letter-spacing: -0.5px;
      margin-bottom: 8px;
    }

    header .meta {
      font-size: 13px;
      color: var(--text-dim);
      font-family: var(--font-mono);
    }

    /* ─── Summary Cards ─── */
    .summary-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
      gap: 16px;
      margin-bottom: 48px;
    }

    .summary-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 20px;
      text-align: center;
    }

    .summary-card .number {
      font-size: 36px;
      font-weight: 700;
      font-family: var(--font-mono);
      line-height: 1;
    }

    .summary-card .label {
      font-size: 12px;
      color: var(--text-dim);
      text-transform: uppercase;
      letter-spacing: 1.5px;
      margin-top: 8px;
    }

    .summary-card.identical .number { color: var(--green); }
    .summary-card.diffs .number { color: var(--amber); }
    .summary-card.errors .number { color: var(--red); }
    .summary-card.only .number { color: var(--purple); }

    /* ─── Scenario Sections ─── */
    .scenario {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 12px;
      margin-bottom: 24px;
      overflow: hidden;
    }

    .scenario-header {
      padding: 20px 24px;
      display: flex;
      align-items: center;
      gap: 12px;
      cursor: pointer;
      user-select: none;
      border-bottom: 1px solid transparent;
      transition: border-color 0.2s;
    }

    .scenario-header:hover { background: var(--surface2); }

    .scenario.open .scenario-header { border-bottom-color: var(--border); }

    .scenario-header .method {
      font-family: var(--font-mono);
      font-size: 11px;
      font-weight: 600;
      padding: 3px 10px;
      border-radius: 4px;
      letter-spacing: 1px;
    }

    .method-POST { background: #0d9488; color: #f0fdfa; }
    .method-PUT { background: #d97706; color: #fffbeb; }
    .method-PATCH { background: #7c3aed; color: #f5f3ff; }
    .method-DELETE { background: #dc2626; color: #fef2f2; }

    .scenario-header .name {
      font-weight: 600;
      font-size: 15px;
      flex: 1;
    }

    .status-badge {
      font-family: var(--font-mono);
      font-size: 11px;
      font-weight: 600;
      padding: 3px 10px;
      border-radius: 4px;
      letter-spacing: 0.5px;
    }

    .status-identical { background: #064e3b; color: #6ee7b7; }
    .status-diffs_found { background: #78350f; color: #fde68a; }
    .status-error { background: #7f1d1d; color: #fca5a5; }
    .status-v1_only, .status-v2_only { background: #312e81; color: #c4b5fd; }

    .scenario-body {
      display: none;
      padding: 24px;
    }

    .scenario.open .scenario-body { display: block; }

    .chevron {
      font-size: 14px;
      color: var(--text-dim);
      transition: transform 0.2s;
    }

    .scenario.open .chevron { transform: rotate(90deg); }

    /* ─── Pair Section ─── */
    .pair {
      margin-bottom: 24px;
      border: 1px solid var(--border);
      border-radius: 8px;
      overflow: hidden;
    }

    .pair-header {
      background: var(--surface2);
      padding: 12px 16px;
      font-family: var(--font-mono);
      font-size: 12px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: var(--text-dim);
    }

    .pair-header .url { color: var(--accent); }

    .payloads {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0;
    }

    .payload-col {
      padding: 16px;
      border-right: 1px solid var(--border);
      overflow-x: auto;
    }

    .payload-col:last-child { border-right: none; }

    .payload-col h4 {
      font-family: var(--font-mono);
      font-size: 11px;
      color: var(--text-dim);
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 12px;
    }

    .payload-col pre {
      font-family: var(--font-mono);
      font-size: 12px;
      line-height: 1.6;
      white-space: pre-wrap;
      word-break: break-all;
      color: var(--text);
      background: var(--bg);
      padding: 12px;
      border-radius: 6px;
    }

    /* ─── Diff Table ─── */
    .diff-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 13px;
      margin-top: 12px;
    }

    .diff-table th {
      text-align: left;
      font-family: var(--font-mono);
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: var(--text-dim);
      padding: 8px 12px;
      border-bottom: 1px solid var(--border);
    }

    .diff-table td {
      padding: 8px 12px;
      border-bottom: 1px solid var(--border);
      font-family: var(--font-mono);
      font-size: 12px;
      vertical-align: top;
    }

    .diff-table tr:last-child td { border-bottom: none; }

    .diff-type {
      font-size: 9px;
      font-weight: 700;
      padding: 2px 6px;
      border-radius: 3px;
      letter-spacing: 0.5px;
      display: inline-block;
    }

    .diff-added { background: #064e3b; color: #6ee7b7; }
    .diff-removed { background: #7f1d1d; color: #fca5a5; }
    .diff-value_changed { background: #78350f; color: #fde68a; }
    .diff-type_changed { background: #312e81; color: #c4b5fd; }
    .diff-array_length_changed { background: #1e3a5f; color: #93c5fd; }

    .val { max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

    /* ─── Rename Detection ─── */
    .renames {
      margin-top: 16px;
      padding: 12px 16px;
      background: #1a1533;
      border: 1px solid #312e81;
      border-radius: 8px;
    }

    .renames h5 {
      font-size: 11px;
      color: var(--purple);
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 8px;
      font-family: var(--font-mono);
    }

    .rename-item {
      font-family: var(--font-mono);
      font-size: 12px;
      padding: 4px 0;
      color: var(--text-dim);
    }

    .rename-item .field { color: var(--purple); }
    .rename-item .arrow { color: var(--text-dim); margin: 0 8px; }
    .rename-item .confidence { color: var(--text-dim); font-size: 10px; }

    /* ─── Unmatched Requests ─── */
    .unmatched {
      margin-top: 16px;
      padding: 12px 16px;
      background: #1c1007;
      border: 1px solid #78350f;
      border-radius: 8px;
    }

    .unmatched h5 {
      font-size: 11px;
      color: var(--amber);
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 8px;
      font-family: var(--font-mono);
    }

    .unmatched-item {
      font-family: var(--font-mono);
      font-size: 12px;
      padding: 4px 0;
      color: var(--text-dim);
    }

    /* ─── Toggle ─── */
    .expand-all {
      font-family: var(--font-mono);
      font-size: 12px;
      color: var(--accent);
      background: none;
      border: 1px solid var(--accent);
      padding: 6px 16px;
      border-radius: 6px;
      cursor: pointer;
      margin-bottom: 24px;
    }

    .expand-all:hover { background: rgba(56, 189, 248, 0.1); }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <h1>⚡ API Payload Comparison Report</h1>
      <div class="meta">Generated: ${timestamp}</div>
    </header>

    <div class="summary-grid">
      <div class="summary-card">
        <div class="number">${summary.total}</div>
        <div class="label">Total Scenarios</div>
      </div>
      <div class="summary-card identical">
        <div class="number">${summary.matched}</div>
        <div class="label">Identical</div>
      </div>
      <div class="summary-card diffs">
        <div class="number">${summary.diffs_found}</div>
        <div class="label">Diffs Found</div>
      </div>
      <div class="summary-card only">
        <div class="number">${summary.v1_only + summary.v2_only}</div>
        <div class="label">Version-Only</div>
      </div>
      <div class="summary-card errors">
        <div class="number">${summary.errors}</div>
        <div class="label">Errors</div>
      </div>
    </div>

    <button class="expand-all" onclick="toggleAll()">Expand / Collapse All</button>

    ${comparisons.map((c) => this.renderComparison(c)).join("\n")}
  </div>

  <script>
    document.querySelectorAll('.scenario-header').forEach(h => {
      h.addEventListener('click', () => h.parentElement.classList.toggle('open'));
    });

    function toggleAll() {
      const scenarios = document.querySelectorAll('.scenario');
      const anyOpen = [...scenarios].some(s => s.classList.contains('open'));
      scenarios.forEach(s => {
        if (anyOpen) s.classList.remove('open');
        else s.classList.add('open');
      });
    }
  </script>
</body>
</html>`;
  }

  renderComparison(comp) {
    const method = comp.method || "API";
    const status = comp.status;

    return `
    <div class="scenario${status === "diffs_found" ? " open" : ""}">
      <div class="scenario-header">
        <span class="chevron">▶</span>
        ${method !== "API" ? `<span class="method method-${method}">${method}</span>` : ""}
        <span class="name">${this.escHtml(comp.scenario)}</span>
        <span class="status-badge status-${status}">${status.replace(/_/g, " ").toUpperCase()}</span>
      </div>
      <div class="scenario-body">
        ${comp.error ? `<p style="color: var(--red); font-family: var(--font-mono); font-size: 13px;">${this.escHtml(comp.error)}</p>` : ""}
        ${(comp.pairs || []).map((p) => this.renderPair(p)).join("\n")}
        ${this.renderUnmatched(comp.v1OnlyRequests, "v1")}
        ${this.renderUnmatched(comp.v2OnlyRequests, "v2")}
      </div>
    </div>`;
  }

  renderPair(pair) {
    return `
    <div class="pair">
      <div class="pair-header">
        <span><span class="method method-${pair.method}">${pair.method}</span></span>
        <span>v1: <span class="url">${this.escHtml(pair.v1Url)}</span> → v2: <span class="url">${this.escHtml(pair.v2Url)}</span></span>
        <span>${pair.identical ? "✅ Identical" : `⚠️ ${pair.diffs.length} diff(s)`}</span>
      </div>

      <div class="payloads">
        <div class="payload-col">
          <h4>v1 Payload</h4>
          <pre>${this.escHtml(JSON.stringify(pair.v1Payload, null, 2) || "(empty)")}</pre>
        </div>
        <div class="payload-col">
          <h4>v2 Payload</h4>
          <pre>${this.escHtml(JSON.stringify(pair.v2Payload, null, 2) || "(empty)")}</pre>
        </div>
      </div>

      ${pair.diffs.length > 0 ? this.renderDiffTable(pair.diffs) : ""}
      ${pair.renames && pair.renames.length > 0 ? this.renderRenames(pair.renames) : ""}
    </div>`;
  }

  renderDiffTable(diffs) {
    const rows = diffs
      .map(
        (d) => `
      <tr>
        <td><span class="diff-type diff-${d.type}">${d.type.replace(/_/g, " ").toUpperCase()}</span></td>
        <td style="color: var(--accent);">${this.escHtml(d.path)}</td>
        <td class="val" style="color: var(--red);" title="${this.escHtml(this.formatVal(d.v1Value))}">${this.escHtml(this.formatVal(d.v1Value))}</td>
        <td class="val" style="color: var(--green);" title="${this.escHtml(this.formatVal(d.v2Value))}">${this.escHtml(this.formatVal(d.v2Value))}</td>
      </tr>`
      )
      .join("");

    return `
    <table class="diff-table">
      <thead><tr><th>Type</th><th>Field Path</th><th>v1 Value</th><th>v2 Value</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
  }

  renderRenames(renames) {
    return `
    <div class="renames">
      <h5>🔄 Possible Field Renames</h5>
      ${renames
        .map(
          (r) =>
            `<div class="rename-item"><span class="field">${this.escHtml(r.v1Field)}</span><span class="arrow">→</span><span class="field">${this.escHtml(r.v2Field)}</span> <span class="confidence">(${Math.round(r.confidence * 100)}% confidence)</span></div>`
        )
        .join("")}
    </div>`;
  }

  renderUnmatched(requests, version) {
    if (!requests || requests.length === 0) return "";
    return `
    <div class="unmatched">
      <h5>⚠️ ${version.toUpperCase()}-Only API Calls (no match in other version)</h5>
      ${requests
        .map((r) => `<div class="unmatched-item">${r.method} ${this.escHtml(r.urlPath)} ${r.body ? "— has payload" : ""}</div>`)
        .join("")}
    </div>`;
  }

  formatVal(v) {
    if (v === undefined) return "—";
    if (v === null) return "null";
    if (typeof v === "object") return JSON.stringify(v);
    return String(v);
  }

  escHtml(str) {
    if (str == null) return "";
    return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
}

module.exports = { ReportGenerator };
