/**
 * Phase 1: Code Analyzer
 * 
 * Scans React/Next.js source code using Babel AST parsing to extract:
 * - All API calls (fetch, axios, useSWR mutations, server actions)
 * - Forms and their fields
 * - Inline-edit patterns
 * - Delete triggers
 * - The route/page each lives on
 * - Payload structure from the code
 */

const fs = require("fs");
const path = require("path");
const parser = require("@babel/parser");
const traverse = require("@babel/traverse").default;
const { glob } = require("glob");

// HTTP methods we care about
const MUTATION_METHODS = ["post", "put", "patch", "delete"];

class CodeAnalyzer {
  constructor(codePath, version) {
    this.codePath = path.resolve(codePath);
    this.version = version;
    this.apiCalls = [];
    this.forms = [];
    this.interactions = [];
  }

  async analyze() {
    console.log(`\n🔍 [${this.version}] Scanning codebase: ${this.codePath}`);

    const files = await glob("**/*.{js,jsx,ts,tsx}", {
      cwd: this.codePath,
      ignore: ["**/node_modules/**", "**/.next/**", "**/dist/**", "**/build/**", "**/*.test.*", "**/*.spec.*"],
      absolute: true,
    });

    console.log(`   Found ${files.length} source files`);

    for (const file of files) {
      try {
        await this.analyzeFile(file);
      } catch (err) {
        // Skip files that can't be parsed (config files, etc.)
      }
    }

    // Deduplicate and enrich
    this.apiCalls = this.deduplicateAPICalls(this.apiCalls);
    this.forms = this.deduplicateForms(this.forms);

    console.log(`   Extracted: ${this.apiCalls.length} API calls, ${this.forms.length} forms, ${this.interactions.length} interactions`);

    return {
      version: this.version,
      apiCalls: this.apiCalls,
      forms: this.forms,
      interactions: this.interactions,
    };
  }

  async analyzeFile(filePath) {
    const code = fs.readFileSync(filePath, "utf-8");
    const relativePath = path.relative(this.codePath, filePath);

    // Determine the route from file path (Next.js conventions)
    const route = this.inferRoute(relativePath);

    const ast = parser.parse(code, {
      sourceType: "module",
      plugins: ["jsx", "typescript", "decorators-legacy", "classProperties", "optionalChaining", "nullishCoalescingOperator"],
      errorRecovery: true,
    });

    const self = this;

    traverse(ast, {
      // ─── Detect fetch() calls ───
      CallExpression(nodePath) {
        const node = nodePath.node;

        // fetch("url", { method: "POST", body: ... })
        if (node.callee.name === "fetch" || (node.callee.property && node.callee.property.name === "fetch")) {
          const apiCall = self.extractFetchCall(node, code, relativePath, route);
          if (apiCall) self.apiCalls.push(apiCall);
        }

        // axios.post / axios.put / axios.delete / axios.patch
        if (node.callee.type === "MemberExpression") {
          const objName = node.callee.object.name || node.callee.object.property?.name || "";
          const methodName = (node.callee.property.name || "").toLowerCase();

          if ((objName.toLowerCase().includes("axios") || objName.toLowerCase().includes("api") || objName.toLowerCase().includes("http") || objName.toLowerCase().includes("client")) && MUTATION_METHODS.includes(methodName)) {
            const apiCall = self.extractAxiosCall(node, methodName, code, relativePath, route);
            if (apiCall) self.apiCalls.push(apiCall);
          }
        }

        // Custom hook calls: useMutation, useSWRMutation, etc.
        if (node.callee.name && /^use(Mutation|SWRMutation|Create|Update|Delete|Submit|Save)/i.test(node.callee.name)) {
          const apiCall = self.extractHookCall(node, code, relativePath, route);
          if (apiCall) self.apiCalls.push(apiCall);
        }
      },

      // ─── Detect <form> elements ───
      JSXOpeningElement(nodePath) {
        const node = nodePath.node;
        const tagName = node.name.name || (node.name.property && node.name.property.name) || "";

        if (tagName.toLowerCase() === "form") {
          const form = self.extractFormElement(nodePath, code, relativePath, route);
          if (form) self.forms.push(form);
        }
      },

      // ─── Detect inline edit patterns ───
      // Look for onBlur, onDoubleClick, contentEditable patterns
      JSXAttribute(nodePath) {
        const node = nodePath.node;
        const attrName = node.name && node.name.name;

        if (["onBlur", "onDoubleClick", "contentEditable"].includes(attrName)) {
          const parent = nodePath.parentPath;
          if (parent && parent.node.type === "JSXOpeningElement") {
            self.interactions.push({
              type: "inline_edit",
              trigger: attrName,
              file: relativePath,
              route,
              element: self.getElementDescription(parent.node),
              line: node.loc?.start.line,
            });
          }
        }
      },
    });
  }

  extractFetchCall(node, code, file, route) {
    const args = node.arguments;
    if (!args.length) return null;

    // Extract URL
    let url = this.extractStringValue(args[0], code);

    // Extract options (second argument)
    let method = "GET";
    let payloadFields = [];
    let payloadSnippet = "";

    if (args[1] && args[1].type === "ObjectExpression") {
      for (const prop of args[1].properties) {
        if (!prop.key) continue;
        const key = prop.key.name || prop.key.value;

        if (key === "method") {
          method = this.extractStringValue(prop.value, code).toUpperCase();
        }
        if (key === "body") {
          const bodyInfo = this.extractPayloadInfo(prop.value, code);
          payloadFields = bodyInfo.fields;
          payloadSnippet = bodyInfo.snippet;
        }
      }
    }

    if (!MUTATION_METHODS.includes(method.toLowerCase())) return null;

    return {
      type: "fetch",
      method,
      url: url || "(dynamic)",
      payloadFields,
      payloadSnippet,
      file,
      route,
      line: node.loc?.start.line,
    };
  }

  extractAxiosCall(node, method, code, file, route) {
    const args = node.arguments;
    const url = args[0] ? this.extractStringValue(args[0], code) : "(dynamic)";
    let payloadFields = [];
    let payloadSnippet = "";

    // For POST/PUT/PATCH, the second arg is typically the payload
    if (["post", "put", "patch"].includes(method) && args[1]) {
      const bodyInfo = this.extractPayloadInfo(args[1], code);
      payloadFields = bodyInfo.fields;
      payloadSnippet = bodyInfo.snippet;
    }

    // For DELETE, payload might be in config.data
    if (method === "delete" && args[1]) {
      const bodyInfo = this.extractPayloadInfo(args[1], code);
      payloadFields = bodyInfo.fields;
      payloadSnippet = bodyInfo.snippet;
    }

    return {
      type: "axios",
      method: method.toUpperCase(),
      url: url || "(dynamic)",
      payloadFields,
      payloadSnippet,
      file,
      route,
      line: node.loc?.start.line,
    };
  }

  extractHookCall(node, code, file, route) {
    const hookName = node.callee.name;
    let method = "POST";
    let url = "(from hook)";
    let payloadFields = [];

    // Try to infer method from hook name
    if (/delete/i.test(hookName)) method = "DELETE";
    else if (/update|edit|patch/i.test(hookName)) method = "PUT";
    else if (/create|add|submit|save/i.test(hookName)) method = "POST";

    // Check first argument for URL
    if (node.arguments[0]) {
      const possibleUrl = this.extractStringValue(node.arguments[0], code);
      if (possibleUrl && possibleUrl.startsWith("/")) url = possibleUrl;
    }

    return {
      type: "hook",
      hookName,
      method,
      url,
      payloadFields,
      payloadSnippet: "",
      file,
      route,
      line: node.loc?.start.line,
    };
  }

  extractFormElement(nodePath, code, file, route) {
    const node = nodePath.node;
    const fields = [];
    let action = "";
    let method = "POST";

    // Check form attributes
    for (const attr of node.attributes) {
      if (!attr.name) continue;
      if (attr.name.name === "action") {
        action = this.extractStringValue(attr.value, code);
      }
      if (attr.name.name === "method") {
        method = this.extractStringValue(attr.value, code).toUpperCase() || "POST";
      }
    }

    // Traverse children to find input fields
    const parentNode = nodePath.parent;
    this.extractFormFields(nodePath, fields, code);

    return {
      action: action || "(onSubmit handler)",
      method,
      fields,
      file,
      route,
      line: node.loc?.start.line,
    };
  }

  extractFormFields(nodePath, fields, code) {
    // Walk the JSX tree to find inputs, selects, textareas
    try {
      nodePath.traverse({
        JSXOpeningElement(innerPath) {
          const el = innerPath.node;
          const tagName = el.name.name || "";

          if (["input", "Input", "select", "Select", "textarea", "Textarea"].includes(tagName)) {
            const field = { tag: tagName.toLowerCase() };

            for (const attr of el.attributes) {
              if (!attr.name) continue;
              const aName = attr.name.name;
              if (["name", "type", "placeholder", "id", "data-testid", "aria-label"].includes(aName)) {
                field[aName] = typeof attr.value === "object" && attr.value.value
                  ? attr.value.value
                  : "(dynamic)";
              }
            }

            if (field.name || field.id || field["data-testid"] || field.placeholder) {
              fields.push(field);
            }
          }
        },
      });
    } catch (e) {
      // Traverse errors are non-fatal
    }
  }

  extractPayloadInfo(node, code) {
    const fields = [];
    let snippet = "";

    try {
      snippet = code.substring(node.start, Math.min(node.end, node.start + 500));
    } catch (e) {}

    if (node.type === "ObjectExpression") {
      for (const prop of node.properties) {
        if (prop.key) {
          fields.push(prop.key.name || prop.key.value || "(computed)");
        }
      }
    }

    // JSON.stringify(someObject) — try to find the variable
    if (node.type === "CallExpression") {
      const callee = node.callee;
      if (callee.object?.name === "JSON" && callee.property?.name === "stringify" && node.arguments[0]) {
        return this.extractPayloadInfo(node.arguments[0], code);
      }
    }

    // Spread or variable reference — just note it
    if (node.type === "Identifier") {
      fields.push(`(ref: ${node.name})`);
    }

    return { fields, snippet };
  }

  extractStringValue(node, code) {
    if (!node) return "";
    if (node.type === "StringLiteral" || node.type === "Literal") return node.value || "";
    if (node.type === "TemplateLiteral") {
      // Reconstruct template literal with placeholders
      let result = "";
      for (let i = 0; i < node.quasis.length; i++) {
        result += node.quasis[i].value.raw;
        if (node.expressions[i]) {
          result += "${...}";
        }
      }
      return result;
    }
    if (node.type === "JSXExpressionContainer") {
      return this.extractStringValue(node.expression, code);
    }
    // For complex expressions, try to get the raw code
    try {
      return code.substring(node.start, node.end);
    } catch (e) {
      return "(dynamic)";
    }
  }

  getElementDescription(jsxNode) {
    const tag = jsxNode.name.name || "unknown";
    const attrs = {};
    for (const attr of jsxNode.attributes || []) {
      if (attr.name && attr.value && attr.value.value) {
        attrs[attr.name.name] = attr.value.value;
      }
    }
    return { tag, ...attrs };
  }

  inferRoute(filePath) {
    // Next.js App Router: app/users/page.tsx → /users
    const appMatch = filePath.match(/app\/(.+?)\/page\.(js|jsx|ts|tsx)$/);
    if (appMatch) return "/" + appMatch[1].replace(/\[([^\]]+)\]/g, ":$1");

    // Next.js Pages Router: pages/users/index.tsx → /users
    const pagesMatch = filePath.match(/pages\/(.+?)\.(js|jsx|ts|tsx)$/);
    if (pagesMatch) {
      let route = pagesMatch[1].replace(/\/index$/, "").replace(/\[([^\]]+)\]/g, ":$1");
      return "/" + route;
    }

    // Fallback: use directory structure
    const dir = path.dirname(filePath);
    return "/" + dir.replace(/^src\/?/, "").replace(/^components\/?/, "~components/");
  }

  deduplicateAPICalls(calls) {
    const seen = new Map();
    for (const call of calls) {
      const key = `${call.method}:${call.url}:${call.file}:${call.line}`;
      if (!seen.has(key)) seen.set(key, call);
    }
    return Array.from(seen.values());
  }

  deduplicateForms(forms) {
    const seen = new Map();
    for (const form of forms) {
      const key = `${form.file}:${form.line}`;
      if (!seen.has(key)) seen.set(key, form);
    }
    return Array.from(seen.values());
  }
}

module.exports = { CodeAnalyzer };
