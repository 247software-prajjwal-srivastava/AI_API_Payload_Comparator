#!/usr/bin/env node

/**
 * API Payload Comparator — Main Entry Point
 * 
 * Usage:
 *   node run.js
 *   node run.js --v1-code ./app-v1 --v2-code ./app-v2 --v1-url https://v1.example.com --v2-url https://v2.example.com
 *   node run.js --analyze-only       (just analyze code, don't run browser)
 *   node run.js --scenarios-only     (analyze + generate scenarios, don't run browser)
 *   node run.js --config ./myconfig.json
 */

const fs = require("fs");
const path = require("path");
const { CodeAnalyzer } = require("./analyze");
const { ScenarioGenerator } = require("./generate-scenarios");
const { ExecutionEngine } = require("./execute");
const { DiffEngine } = require("./diff-engine");
const { ReportGenerator } = require("./report-generator");

// ─── Parse CLI args ───
function parseArgs() {
  const args = process.argv.slice(2);
  const parsed = {};

  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case "--v1-code":
        parsed.v1Code = args[++i];
        break;
      case "--v2-code":
        parsed.v2Code = args[++i];
        break;
      case "--v1-url":
        parsed.v1Url = args[++i];
        break;
      case "--v2-url":
        parsed.v2Url = args[++i];
        break;
      case "--config":
        parsed.configPath = args[++i];
        break;
      case "--analyze-only":
        parsed.analyzeOnly = true;
        break;
      case "--scenarios-only":
        parsed.scenariosOnly = true;
        break;
      case "--headed":
        parsed.headed = true;
        break;
      case "--help":
        printHelp();
        process.exit(0);
    }
  }

  return parsed;
}

function printHelp() {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║          API Payload Comparator — v1 vs v2                  ║
╚══════════════════════════════════════════════════════════════╝

  Automatically analyzes your React/Next.js codebases,
  generates test scenarios, runs them on both UIs,
  and compares the API payloads.

USAGE:
  node run.js [options]

OPTIONS:
  --config <path>       Path to config.json (default: ./config.json)
  --v1-code <path>      Override v1 codebase path
  --v2-code <path>      Override v2 codebase path
  --v1-url <url>        Override v1 staging URL
  --v2-url <url>        Override v2 staging URL
  --analyze-only        Only analyze code (no browser execution)
  --scenarios-only      Analyze code + generate scenarios (no browser)
  --headed              Run browser in headed mode (visible)
  --help                Show this help

QUICK START:
  1. Edit config.json with your URLs and code paths
  2. Run: node run.js
  3. Open reports/report.html

EXAMPLES:
  node run.js
  node run.js --v1-code ../old-app --v2-code ../new-app
  node run.js --headed --v1-url http://localhost:3000 --v2-url http://localhost:3001
  node run.js --analyze-only
`);
}

// ─── Main ───
async function main() {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║          API Payload Comparator — v1 vs v2                  ║
║          Automated CRUD Payload Diffing Tool                ║
╚══════════════════════════════════════════════════════════════╝
  `);

  const cliArgs = parseArgs();

  // Load config
  const configPath = path.resolve(cliArgs.configPath || "./config.json");
  if (!fs.existsSync(configPath)) {
    console.error(`❌ Config file not found: ${configPath}`);
    console.error(`   Run with --help for usage info`);
    process.exit(1);
  }

  const config = JSON.parse(fs.readFileSync(configPath, "utf-8"));

  // Apply CLI overrides
  if (cliArgs.v1Code) config.v1.codePath = cliArgs.v1Code;
  if (cliArgs.v2Code) config.v2.codePath = cliArgs.v2Code;
  if (cliArgs.v1Url) config.v1.baseUrl = cliArgs.v1Url;
  if (cliArgs.v2Url) config.v2.baseUrl = cliArgs.v2Url;
  if (cliArgs.headed) config.options.headless = false;

  // Validate code paths exist
  for (const version of ["v1", "v2"]) {
    const codePath = path.resolve(config[version].codePath);
    if (!fs.existsSync(codePath)) {
      console.error(`❌ ${version} code path not found: ${codePath}`);
      console.error(`   Update config.json or pass --${version}-code <path>`);
      process.exit(1);
    }
  }

  // ═══════════════════════════════════════════
  // Phase 1: Analyze both codebases
  // ═══════════════════════════════════════════
  console.log("═══ PHASE 1: CODE ANALYSIS ═══");

  const v1Analyzer = new CodeAnalyzer(config.v1.codePath, "v1");
  const v2Analyzer = new CodeAnalyzer(config.v2.codePath, "v2");

  const v1Analysis = await v1Analyzer.analyze();
  const v2Analysis = await v2Analyzer.analyze();

  // Save analysis results
  const analysisOutput = { v1: v1Analysis, v2: v2Analysis };
  const reportsDir = path.join(process.cwd(), "reports");
  if (!fs.existsSync(reportsDir)) fs.mkdirSync(reportsDir, { recursive: true });
  fs.writeFileSync(
    path.join(reportsDir, "analysis.json"),
    JSON.stringify(analysisOutput, null, 2)
  );
  console.log(`   Analysis saved to reports/analysis.json`);

  if (cliArgs.analyzeOnly) {
    console.log("\n✅ Analysis complete (--analyze-only). Exiting.");
    printAnalysisSummary(v1Analysis, v2Analysis);
    process.exit(0);
  }

  // ═══════════════════════════════════════════
  // Phase 2: Generate scenarios
  // ═══════════════════════════════════════════
  console.log("\n═══ PHASE 2: SCENARIO GENERATION ═══");

  const generator = new ScenarioGenerator(v1Analysis, v2Analysis, config.options.testData);
  const scenarios = generator.generate();

  // Save scenarios
  fs.writeFileSync(
    path.join(reportsDir, "scenarios.json"),
    JSON.stringify(scenarios, null, 2)
  );
  console.log(`   Scenarios saved to reports/scenarios.json`);

  if (cliArgs.scenariosOnly) {
    console.log("\n✅ Scenarios generated (--scenarios-only). Exiting.");
    console.log(`   Review reports/scenarios.json and then run without --scenarios-only`);
    process.exit(0);
  }

  // ═══════════════════════════════════════════
  // Phase 3: Execute scenarios
  // ═══════════════════════════════════════════
  console.log("\n═══ PHASE 3: BROWSER EXECUTION ═══");

  const engine = new ExecutionEngine(config);
  const executionResults = await engine.run(scenarios);

  // Save raw results
  fs.writeFileSync(
    path.join(reportsDir, "execution-results.json"),
    JSON.stringify(executionResults, null, 2, (key, value) => {
      // Avoid serializing huge screenshot buffers
      if (key === "screenshot" && typeof value === "string" && value.length > 200) {
        return value; // keep path
      }
      return value;
    })
  );

  // ═══════════════════════════════════════════
  // Phase 4: Diff and Report
  // ═══════════════════════════════════════════
  console.log("\n═══ PHASE 4: DIFF & REPORT ═══");

  const diffEngine = new DiffEngine(config.options.ignoredPayloadFields);
  const diffReport = diffEngine.compareResults(executionResults);

  // Save JSON report
  fs.writeFileSync(
    path.join(reportsDir, "diff-report.json"),
    JSON.stringify(diffReport, null, 2)
  );

  // Generate HTML report
  const reportGen = new ReportGenerator();
  const htmlPath = path.join(reportsDir, "report.html");
  reportGen.generate(diffReport, htmlPath);

  // ─── Done ───
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║  ✅ COMPLETE                                                ║
╠══════════════════════════════════════════════════════════════╣
║  Reports:                                                   ║
║    📊 reports/report.html        (visual diff report)       ║
║    📋 reports/analysis.json      (code analysis)            ║
║    📋 reports/scenarios.json     (generated test plans)     ║
║    📋 reports/diff-report.json   (machine-readable diffs)   ║
║    📋 reports/execution-results.json  (raw captures)        ║
╚══════════════════════════════════════════════════════════════╝
  `);

  // Open report in browser (best effort)
  try {
    const { exec } = require("child_process");
    const openCmd = process.platform === "darwin" ? "open" : process.platform === "win32" ? "start" : "xdg-open";
    exec(`${openCmd} ${htmlPath}`);
  } catch (e) {
    // Silently fail if can't open browser
  }
}

function printAnalysisSummary(v1, v2) {
  console.log("\n── v1 API Calls ──");
  for (const call of v1.apiCalls) {
    console.log(`   ${call.method} ${call.url} (${call.file}:${call.line})`);
    if (call.payloadFields.length) {
      console.log(`      Fields: ${call.payloadFields.join(", ")}`);
    }
  }
  console.log("\n── v2 API Calls ──");
  for (const call of v2.apiCalls) {
    console.log(`   ${call.method} ${call.url} (${call.file}:${call.line})`);
    if (call.payloadFields.length) {
      console.log(`      Fields: ${call.payloadFields.join(", ")}`);
    }
  }
}

main().catch((err) => {
  console.error("\n❌ Fatal error:", err.message);
  console.error(err.stack);
  process.exit(1);
});
